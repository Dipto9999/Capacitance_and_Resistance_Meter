#ifndef __VERSION_H__
#define __VERSION_H__

// To update the revision number run:
// SubWCRev c:\source\test version.in version.h

int revison_number = 170 + 1000;

#endif
